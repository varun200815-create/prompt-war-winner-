# BRIDGE AI V7 — Friendly Multilingual Civic Interface

This version is optimized for accessibility and ease of reporting:
- Indian language selector: English, Hindi, Kannada, Tamil, Telugu, Malayalam, Bengali, Marathi, Gujarati, Punjabi
- Gemini-powered translation
- Indian city/state area selector
- browser-location option (permission-based)
- rational regional reasoning with explicit caveat: AI context, not live GIS
- prominent beginner-friendly report input
- text + image analysis
- action plan, evidence/verification boundary, and human confirmation
- AI copilot chat
- lighter cinematic styling with calmer information density

## Local
1. Create `.env` from `.env.example`.
2. Add your fresh Gemini key.
3. `python -m pip install -r requirements.txt`
4. `python -m uvicorn main:app --reload`
5. Open http://127.0.0.1:8000

## Test
`python -m pytest`

## Trust
The app does not claim live government, police, map, weather or authority integration.
Regional reasoning is contextual AI reasoning based on the supplied report and selected area.


## V7 UI update
The landing/report area now places an India-centered Earth visual directly beside the primary report input. Language and area controls are positioned above the textarea for faster first-time access.

## Helper availability
Added compact Doctor Help, Career Helper, Civic Support, and General Helper availability/type cards. These are clearly labeled as UI/demo service states rather than live external bookings or placements.
