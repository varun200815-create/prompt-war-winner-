import json
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from google import genai
from google.genai import types

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise RuntimeError("GEMINI_API_KEY is missing from .env")

MODEL = os.getenv("GEMINI_MODEL", "gemini-3.6-flash")
MAX_IMAGE_BYTES = 8 * 1024 * 1024
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp"}

client = genai.Client(api_key=API_KEY)

app = FastAPI(
    title="BRIDGE AI",
    version="7.0",
    docs_url="/docs",
    redoc_url=None,
)
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def home():
    return FileResponse("static/index.html")


@app.get("/health")
def health():
    return {"status": "online", "model": MODEL, "version": "7.0"}


@app.get("/api/status")
def api_status():
    return {
        "ai_analysis": {"status": "AVAILABLE"},
        "translation": {"status": "AVAILABLE"},
        "vision": {"status": "AVAILABLE"},
        "regional_reasoning": {"status": "AVAILABLE", "source": "AI context"},
        "human_confirmation": {"status": "AVAILABLE"},
        "external_verification": {"status": "NOT CONNECTED"},
        "live_authority_dispatch": {"status": "DEMO ONLY"},
    }


def clean(value: object, default: str = "") -> str:
    text = str(value or "").strip()
    return text[:5000] if text else default


@app.post("/translate")
async def translate(data: dict):
    text = clean(data.get("text"))
    target = clean(data.get("target"), "English")

    if not text:
        raise HTTPException(400, "Text to translate is empty.")

    allowed = {
        "English", "Hindi", "Kannada", "Tamil", "Telugu",
        "Malayalam", "Bengali", "Marathi", "Gujarati", "Punjabi"
    }
    if target not in allowed:
        raise HTTPException(400, "Unsupported language.")

    try:
        prompt = f"""
Translate the following user report into {target}.
Preserve meaning, uncertainty, severity, names and numbers.
Do not add facts. Do not summarize.
Return only the translated text.

USER TEXT:
{text}
"""
        response = client.models.generate_content(
            model=MODEL,
            contents=[prompt],
            config=types.GenerateContentConfig(temperature=0.0),
        )
        return {"translation": (response.text or "").strip(), "target": target}

    except Exception as exc:
        print("TRANSLATION ERROR:", type(exc).__name__, str(exc))
        raise HTTPException(500, "Translation is unavailable right now.")


@app.post("/regional-analysis")
async def regional_analysis(data: dict):
    text = clean(data.get("text"))
    city = clean(data.get("city"), "Not selected")
    state = clean(data.get("state"), "Not selected")

    if not text:
        raise HTTPException(400, "Provide a report for regional analysis.")

    try:
        prompt = """
You are the BRIDGE AI regional reasoning layer.

Use only the supplied report and the selected Indian location.
Do not invent live weather, traffic, crime, government service availability,
population, GIS measurements, road conditions or current events.

Give a rational, clearly caveated regional assessment based on the category
and situation described.

Return ONLY valid JSON:
{
  "region": "city, state",
  "relevance": "HIGH|MEDIUM|LOW|UNKNOWN",
  "reasoning": "2-3 concise sentences explaining why the selected region matters to the reported issue, without unsupported factual claims",
  "context_factors": ["factor 1","factor 2","factor 3"],
  "verification_needs": ["regional fact to verify 1","regional fact to verify 2"]
}
"""
        response = client.models.generate_content(
            model=MODEL,
            contents=[
                prompt,
                f"SELECTED CITY: {city}\nSELECTED STATE: {state}\nREPORT:\n{text}",
            ],
            config=types.GenerateContentConfig(
                temperature=0.1,
                response_mime_type="application/json",
            ),
        )
        raw = (response.text or "").strip()
        if raw.startswith("```"):
            raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)
        result.setdefault("region", f"{city}, {state}")
        result.setdefault("relevance", "UNKNOWN")
        result.setdefault("reasoning", "Regional context requires verification.")
        result.setdefault("context_factors", [])
        result.setdefault("verification_needs", [])
        return result

    except json.JSONDecodeError:
        raise HTTPException(502, "Regional reasoning returned invalid JSON.")
    except Exception as exc:
        print("REGIONAL ERROR:", type(exc).__name__, str(exc))
        raise HTTPException(500, "Regional reasoning is unavailable right now.")


@app.post("/analyze")
async def analyze(
    message: str = Form(""),
    image: Optional[UploadFile] = File(None),
    language: str = Form("English"),
    city: str = Form("Not selected"),
    state: str = Form("Not selected"),
):
    message = clean(message)

    if not message and not image:
        raise HTTPException(400, "Add a report or an image.")

    try:
        prompt = """
You are BRIDGE AI, a universal bridge between human intent and complex systems.

Convert messy human reports into:
UNDERSTAND → EXTRACT → VERIFY → RECOMMEND → HUMAN CONFIRM

Return ONLY valid JSON:
{
  "severity": "LOW|MEDIUM|HIGH|CRITICAL",
  "intent": "one concise sentence",
  "summary": "two concise sentences",
  "category": "FLOOD|POTHOLE|LIGHTING|FIRE|TRAFFIC|WASTE|ENVIRONMENT|ACCESSIBILITY|OTHER",
  "location_hint": "location explicitly mentioned in the report or Unknown",
  "key_facts": ["fact","fact","fact","fact"],
  "recommended_actions": ["action","action","action","action"],
  "evidence": {
    "status": "USER REPORTED|IMAGE EVIDENCE|MIXED",
    "details": "what the input actually supports"
  },
  "verification": {
    "status": "PENDING",
    "next_step": "what should be independently checked"
  },
  "confidence": 0
}

Rules:
- Never claim that a government authority, police service, live sensor, map feed,
  weather service, database or emergency service was contacted.
- User statements are user-reported.
- Image observations must be visually defensible.
- Separate observation from assumption.
- Actions must be safe and practical.
- Human confirmation is required before a dispatch state.
- Confidence is an integer from 0 to 100.
- The user's selected language may be used for understanding, but the JSON values
  must be in English so the dashboard can translate them consistently.
"""
        contents = [
            prompt,
            f"SELECTED LANGUAGE: {language}",
            f"SELECTED AREA: {city}, {state}",
            "\nUSER REPORT:\n" + (message or "[No text; inspect the image.]"),
        ]

        if image:
            if image.content_type not in ALLOWED_IMAGE_TYPES:
                raise HTTPException(400, "Use a JPG, PNG or WEBP image.")
            data = await image.read()
            if len(data) > MAX_IMAGE_BYTES:
                raise HTTPException(413, "Image is too large. Maximum size is 8 MB.")
            if not data:
                raise HTTPException(400, "Uploaded image is empty.")
            contents.append(
                types.Part.from_bytes(
                    data=data,
                    mime_type=image.content_type,
                )
            )

        response = client.models.generate_content(
            model=MODEL,
            contents=contents,
            config=types.GenerateContentConfig(
                temperature=0.12,
                response_mime_type="application/json",
            ),
        )

        raw = (response.text or "").strip()
        if raw.startswith("```"):
            raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)

        severity = str(result.get("severity", "MEDIUM")).upper()
        if severity not in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}:
            severity = "MEDIUM"

        category = str(result.get("category", "OTHER")).upper()
        allowed_categories = {
            "FLOOD", "POTHOLE", "LIGHTING", "FIRE", "TRAFFIC",
            "WASTE", "ENVIRONMENT", "ACCESSIBILITY", "OTHER"
        }
        if category not in allowed_categories:
            category = "OTHER"

        result["severity"] = severity
        result["category"] = category
        result.setdefault("intent", "Understand and respond to the report.")
        result.setdefault("summary", "A report requires review.")
        result.setdefault("location_hint", "Unknown")
        result.setdefault("key_facts", [])
        result.setdefault("recommended_actions", [])
        result.setdefault(
            "evidence",
            {"status": "USER REPORTED", "details": "Information came from supplied input."},
        )
        result.setdefault(
            "verification",
            {"status": "PENDING", "next_step": "Independently verify before official action."},
        )
        try:
            result["confidence"] = max(
                0, min(100, int(result.get("confidence", 70)))
            )
        except Exception:
            result["confidence"] = 70

        return result

    except json.JSONDecodeError:
        raise HTTPException(502, "AI returned an invalid structured response.")
    except HTTPException:
        raise
    except Exception as exc:
        print("ANALYZE ERROR:", type(exc).__name__, str(exc))
        raise HTTPException(
            500, "BRIDGE could not complete the analysis. Check the server terminal."
        )


@app.post("/chat")
async def chat(data: dict):
    message = clean(data.get("message"))
    context = data.get("context") or {}

    if not message:
        raise HTTPException(400, "Chat message is empty.")

    try:
        context_text = json.dumps(context, ensure_ascii=False)[:8000]
        prompt = """
You are the BRIDGE AI accessibility and civic copilot.

Answer in simple, friendly language.
Help the user understand reports, evidence, verification, regional reasoning,
translations and next steps.

Never claim live authority contact or external verification.
Do not invent current local data.
Keep responses below 120 words.
"""
        response = client.models.generate_content(
            model=MODEL,
            contents=[
                prompt,
                f"CURRENT CASE:\n{context_text}\n\nUSER:\n{message}",
            ],
            config=types.GenerateContentConfig(temperature=0.25),
        )
        return {"reply": (response.text or "I couldn't generate a response.").strip()}

    except Exception as exc:
        print("CHAT ERROR:", type(exc).__name__, str(exc))
        raise HTTPException(500, "The AI assistant is unavailable right now.")


@app.post("/report")
async def report(data: dict):
    return {
        "case_id": "BR-" + uuid.uuid4().hex[:6].upper(),
        "status": "ACTION READY",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


@app.post("/confirm")
async def confirm(data: dict):
    return {
        "case_id": clean(data.get("case_id"), "UNKNOWN")[:64],
        "status": "ACTION DISPATCHED",
        "confirmed_at": datetime.now(timezone.utc).isoformat(),
    }
