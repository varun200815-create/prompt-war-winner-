BRIDGE AI V5 — CINEMATIC, MODERN & FRIENDLY CIVIC AI

1. Extract the ZIP.
2. Keep your existing .env with GEMINI_API_KEY=YOUR_FRESH_KEY.
3. Open the project in VS Code.
4. Run:
   python -m pip install -r requirements.txt
5. Run:
   python -m uvicorn main:app --reload
6. Open:
   http://127.0.0.1:8000

V5.1 visual and UX direction:
- cinematic modern interface instead of cyberpunk command-center styling
- friendly light glassmorphism with soft blue, lavender and warm accent gradients
- plain-language reporting experience designed for non-technical users
- text + photo + voice entry affordances
- clear human-in-the-loop confirmation
- responsive mobile-friendly layout
- reduced visual noise and technical jargon
- accessible focus states and larger touch targets
- image validation and client-side compression before Gemini processing

Important:
The demo deliberately labels external verification and dispatch as unavailable/demo-only.
